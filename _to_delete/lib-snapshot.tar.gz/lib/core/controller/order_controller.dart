import 'package:get/get.dart';
import 'package:lacarta/core/constant/order_status.dart';
import 'package:lacarta/core/models/order.dart';
import 'package:lacarta/core/services/order_service.dart';
import 'package:lacarta/main.dart';
import 'package:url_launcher/url_launcher.dart';

class OrderController extends GetxController {
  var orderType = "dine_in".obs;

  final OrderService _orderService = OrderService();

  Future<void> saveOrder(OrderCart order) async {
    try {
      // 1. Guardar el pedido en la base de datos
      await _orderService.saveOrder(order, currentRestaurant['id'] as String);

      // 2. Mandarlo también por WhatsApp
      await sendToWhatsApp(order);
    } catch (e) {
      Get.snackbar('Error', 'No se pudo enviar el pedido');
    }
  }

  Future<void> sendToWhatsApp(OrderCart order) async {
    final message = buildWhatsAppMessage(order);

    // Antes estaba hardcodeado a un solo número. Ahora sale del
    // restaurante actual. Asegúrate de tener una columna `whatsapp_phone`
    // (o como la llames) en tu tabla `restaurants` en Supabase.
    final phone = currentRestaurant['whatsapp_phone'] as String?;

    if (phone == null || phone.isEmpty) {
      Get.snackbar('Error', 'Este restaurante no tiene WhatsApp configurado');
      return;
    }

    final url = Uri.parse("https://wa.me/$phone?text=$message");

    final launched = await launchUrl(url, webOnlyWindowName: "_blank");

    if (!launched) {
      Get.snackbar('Error', 'No se pudo abrir WhatsApp');
    }
  }

  String buildWhatsAppMessage(OrderCart order) {
    String message = "*Nuevo Pedido*\n\n";

    if (order.type == OrderType.delivery) {
      message += "*Domicilio*\n";
      message += "Cliente: ${order.customerName}\n";
      message += "Tel: ${order.phone}\n";
      message += "Dirección: ${order.address}\n\n";
    }

    if (order.type == OrderType.takeaway) {
      message += "*Para recoger*\n";
      message += "Nombre: ${order.customerName}\n";

      if (order.phone != null && order.phone!.isNotEmpty) {
        message += "Tel: ${order.phone}\n";
      }

      message += "\n";
    }

    if (order.type == OrderType.dineIn) {
      message += "*Comer en el sitio*\n";
      message += "Mesa: ${order.table}\n\n";
    }

    message += "-------------------\n";
    message += "*Pedido*\n\n";

    for (var item in order.items) {
      message += "${item.quantity} x ${item.product.name}\n";

      for (var extra in item.extras) {
        message += "   + ${extra.optionName} x${extra.quantity}\n";
      }

      if (item.comment.isNotEmpty) {
        message += "Comentario: ${item.comment}\n";
      }

      message += "   Subtotal: \$${item.total}\n\n";
    }

    message += "-------------------\n";
    message += "*TOTAL: \$${order.total}*\n";

    return Uri.encodeComponent(message);
  }
}