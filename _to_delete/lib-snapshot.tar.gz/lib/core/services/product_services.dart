import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:lacarta/core/models/product/producto.dart';

class ProductServices {
  final SupabaseClient _client = Supabase.instance.client;
  final String table = 'products';

  /// SAVE
  Future<String> saveProduct(Product product, String restaurantId) async {
    try {
      final data = product.toMap()..['restaurant_id'] = restaurantId;

      final response = await _client.from(table).insert(data).select().single();

      return response['id'] as String;
    } catch (e) {
      throw Exception("Error guardando producto: $e");
    }
  }

  /// GET
  /// Antes traía TODOS los productos sin filtro — ahora es obligatorio
  /// pasar restaurantId. categoryId es opcional, para cuando quieras
  /// el menú filtrado por categoría en vez del listado completo.
  Future<List<Product>> getProducts(String restaurantId, {String? categoryId}) async {
    try {
      var query = _client
          .from(table)
          .select()
          .eq('restaurant_id', restaurantId)
          .eq('active', true);

      if (categoryId != null) {
        query = query.eq('category_id', categoryId);
      }

      final data = await query.order('name');

      return (data as List)
          .map((row) => Product.fromMap(row as Map<String, dynamic>, row['id'] as String))
          .toList();
    } catch (e) {
      throw Exception("Error obteniendo productos: $e");
    }
  }

  /// UPDATE
  Future<void> updateProduct(Product product) async {
    try {
      await _client.from(table).update(product.toMap()).eq('id', product.toMap()['id']);
    } catch (e) {
      throw Exception("Error actualizando producto: $e");
    }
  }
}