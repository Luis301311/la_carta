import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:lacarta/core/models/order.dart';

class OrderService {
  final SupabaseClient _client = Supabase.instance.client;
  final String ordersTable = 'orders';
  final String itemsTable = 'order_items';

  /// SAVE
  /// Antes esto era un solo documento con los items adentro. En el
  /// esquema relacional son DOS inserts: uno en `orders` y otro
  /// (varias filas) en `order_items`.
  ///
  /// Ajusta los nombres de campo (customerName, items, etc.) a como
  /// se llamen realmente en tu clase OrderCart — te dejo la forma,
  /// pero no tengo el modelo exacto.
  Future<String> saveOrder(OrderCart order, String restaurantId) async {
    try {
      // 1. Insertar el pedido y obtener su id
      final orderRow = await _client
          .from(ordersTable)
          .insert({
            'restaurant_id': restaurantId,
            'customer_name': order.customerName,
            'total': order.total,
          })
          .select()
          .single();

      final orderId = orderRow['id'] as String;

      // 2. Insertar los items del pedido, ya con el order_id generado
      final itemsData = order.items
          .map((item) => {
                'order_id': orderId,
                'product_id': item.product.id,
                'quantity': item.quantity,
                'unit_price': item.product.basePrice,
              })
          .toList();

      if (itemsData.isNotEmpty) {
        await _client.from(itemsTable).insert(itemsData);
      }

      return orderId;
    } catch (e) {
      // Antes esto fallaba en silencio (faltaba el await). Ahora
      // cualquier error se propaga y lo puedes mostrar al usuario.
      throw Exception("Error guardando el pedido: $e");
    }
  }
}