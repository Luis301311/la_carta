import 'package:supabase_flutter/supabase_flutter.dart';

/// Reemplaza a CompanyService. En el esquema nuevo, "company" ya no es
/// una colección aparte: cada restaurante es una fila en la tabla
/// `restaurants`, así que este servicio lee/edita esa misma fila.
///
/// Si necesitas más campos de "empresa" (teléfono, dirección, horario,
/// descripción), agrégalos como columnas a `restaurants` con:
///   ALTER TABLE restaurants ADD COLUMN phone text;
///   ALTER TABLE restaurants ADD COLUMN address text;
///   ALTER TABLE restaurants ADD COLUMN description text;
/// y regenera el modelo Company con esos campos si quieres seguir
/// llamándolo así en tu código Flutter.
class RestaurantService {
  final SupabaseClient _client = Supabase.instance.client;
  final String table = 'restaurants';

  /// GET por slug (para cargar el restaurante actual al abrir la app)
  Future<Map<String, dynamic>?> getRestaurantBySlug(String slug) async {
    try {
      return await _client
          .from(table)
          .select()
          .eq('slug', slug)
          .eq('active', true)
          .maybeSingle();
    } catch (e) {
      throw Exception("Error obteniendo restaurante: $e");
    }
  }

  /// GET por id (útil dentro del panel de administración)
  Future<Map<String, dynamic>?> getRestaurantById(String id) async {
    try {
      return await _client.from(table).select().eq('id', id).maybeSingle();
    } catch (e) {
      throw Exception("Error obteniendo restaurante: $e");
    }
  }

  /// UPDATE — solo funciona si el usuario logueado es owner/staff de
  /// ESTE restaurante; lo garantiza tu política RLS "owner actualiza
  /// su restaurante".
  Future<void> updateRestaurant(String id, Map<String, dynamic> data) async {
    try {
      await _client.from(table).update(data).eq('id', id);
    } catch (e) {
      throw Exception("Error actualizando restaurante: $e");
    }
  }
}