import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Antes del cambio, crea en el dashboard de Supabase un bucket
/// llamado 'products' (Storage > New bucket, márcalo como público
/// para que las imágenes del menú se vean sin login).
class StorageService {
  final SupabaseClient _client = Supabase.instance.client;
  final String bucket = 'products';

  /// Ahora las imágenes van en una carpeta por restaurante dentro del
  /// bucket, para mantenerlas organizadas y poder aplicar políticas de
  /// Storage por restaurante si más adelante lo necesitas.
  Future<String> uploadProductImage(Uint8List bytes, String restaurantId) async {
    try {
      final path = '$restaurantId/${DateTime.now().millisecondsSinceEpoch}.jpg';

      await _client.storage.from(bucket).uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );

      return _client.storage.from(bucket).getPublicUrl(path);
    } catch (e) {
      // Antes había prints de debug sueltos; ahora el error se propaga
      // como excepción para que la UI lo maneje (mostrar un mensaje,
      // reintentar, etc.) en vez de solo imprimirse en consola.
      throw Exception("Error subiendo imagen: $e");
    }
  }
}