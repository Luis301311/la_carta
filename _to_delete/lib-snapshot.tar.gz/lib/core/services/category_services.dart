import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:lacarta/core/models/category.dart';

class CategoryServices {
  final SupabaseClient _client = Supabase.instance.client;
  final String table = 'categories';

  /// SAVE
  /// Nota: category.toMap() ya no debe incluir 'id' si es nulo/vacío en
  /// creación — deja que Postgres genere el UUID con gen_random_uuid().
  Future<String> saveCategory(ProductCategory category, String restaurantId) async {
    try {
      final data = category.toMap()..['restaurant_id'] = restaurantId;

      final response = await _client
          .from(table)
          .upsert(data) // upsert: sirve tanto para crear como actualizar
          .select()
          .single();

      return response['id'] as String;
    } catch (e) {
      throw Exception("Error guardando categoría: $e");
    }
  }

  /// GET
  /// IMPORTANTE: siempre filtra por restaurantId — sin esto, en el
  /// esquema nuevo (una sola base compartida) traerías categorías de
  /// TODOS los restaurantes.
  Future<List<ProductCategory>> getCategories(String restaurantId) async {
    try {
      final data = await _client
          .from(table)
          .select()
          .eq('restaurant_id', restaurantId)
          .order('sort_order'); // antes: 'order' — reservado en SQL, se renombró

      return (data as List)
          .map((row) => ProductCategory.fromMap(row as Map<String, dynamic>, row['id'] as String))
          .toList();
    } catch (e) {
      throw Exception("Error obteniendo categorías: $e");
    }
  }
}