import 'dart:async';
import 'package:get/get.dart';
import 'package:lacarta/core/models/company/business_hours.dart';
import 'package:lacarta/core/models/company/company.dart';
import 'package:lacarta/core/services/company_service.dart';
import 'package:lacarta/main.dart';

class RestaurantController extends GetxController {
  final RestaurantService restaurantService = RestaurantService();
  Rxn<Company> company = Rxn<Company>();
  RxBool isLoading = false.obs;
  RxBool isOpen = false.obs;

  Timer? _openStatusTimer;

  @override
  void onInit() {
    super.onInit();
    fetchCompany();

    ever(company, (_) => checkIfOpen());

    // Antes esto era un Future.doWhile que nunca se detenía, ni al
    // cerrar el controller. Ahora es un Timer que sí se cancela en
    // onClose().
    _openStatusTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      checkIfOpen();
    });
  }

  @override
  void onClose() {
    _openStatusTimer?.cancel();
    super.onClose();
  }

  // GET
  // Ya no hace falta buscar "la primera de la lista": el restaurante
  // actual ya se cargó una vez en main.dart (currentRestaurant), esto
  // solo lo vuelve a traer con el modelo Company completo.
  void fetchCompany() async {
    isLoading.value = true;

    try {
      final data = await restaurantService.getRestaurantById(
        currentRestaurant['id'] as String,
      );

      if (data != null) {
        company.value = Company.fromMap(data, data['id'] as String);
      }
    } catch (e) {
      Get.snackbar('Error', 'No se pudo cargar la información del restaurante');
    } finally {
      isLoading.value = false;
    }
  }

  // UPDATE
  Future<void> updateCompany(Company updatedCompany) async {
    try {
      isLoading.value = true;

      await restaurantService.updateRestaurant(
        updatedCompany.id,
        updatedCompany.toMap(),
      );

      company.value = updatedCompany;

      Get.snackbar('Éxito', 'Restaurante actualizado correctamente');
    } catch (e) {
      Get.snackbar('Error', 'Error actualizando el restaurante');
    } finally {
      isLoading.value = false;
    }
  }

  // NOTA: se quitó createCompany(). Crear un restaurante nuevo ya no
  // es algo que pase dentro de la app de un restaurante individual —
  // es una acción de superadmin (ver el flujo de "crear restaurante +
  // invitar owner" que armamos en Supabase). Si necesitas un panel de
  // superadmin para esto, es un controller/servicio aparte.

  void checkIfOpen() {
    if (company.value != null) {
      isOpen.value = isCompanyOpen(company.value!);
    }
  }

  bool isCompanyOpen(Company company) {
    final now = DateTime.now();

    final currentDay = _getDayName(now.weekday);

    final todaySchedule = company.businessHours.firstWhere(
      (h) => h.day == currentDay,
      orElse: () => BusinessHours(
        day: currentDay,
        openTime: "",
        closeTime: "",
        closed: true,
      ),
    );

    if (todaySchedule.closed) return false;

    final openParts = todaySchedule.openTime.split(":");
    final closeParts = todaySchedule.closeTime.split(":");

    final openTime = DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(openParts[0]),
      int.parse(openParts[1]),
    );

    final closeTime = DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(closeParts[0]),
      int.parse(closeParts[1]),
    );

    return now.isAfter(openTime) && now.isBefore(closeTime);
  }

  String _getDayName(int weekday) {
    switch (weekday) {
      case 1:
        return "Monday";
      case 2:
        return "Tuesday";
      case 3:
        return "Wednesday";
      case 4:
        return "Thursday";
      case 5:
        return "Friday";
      case 6:
        return "Saturday";
      case 7:
        return "Sunday";
      default:
        return "";
    }
  }
}