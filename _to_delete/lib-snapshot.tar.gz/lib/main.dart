import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:lacarta/app_pages.dart';
import 'package:lacarta/config/app_routes.dart';
import 'package:lacarta/core/controller/cart_controller.dart';

late Map<String, dynamic> currentRestaurant;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://cntopgsvlqqnvvizbwyr.supabase.co/rest/v1/',
    anonKey: 'sb_publishable_2SnI51cOicjPgGJSALyudg_w7Tl35oz',
  );

  final slug = Uri.base.pathSegments.isNotEmpty
      ? Uri.base.pathSegments.first
      : "burger_house";

  final data = await Supabase.instance.client
      .from('restaurants')
      .select()
      .eq('slug', slug)
      .eq('active', true)
      .maybeSingle();

  if (data == null) {
    throw Exception("Cliente no encontrado");
  }

  currentRestaurant = data;

  Get.put(CartController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: "La Carta",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
        primaryColor: Colors.blue,
      ),
      initialRoute: AppRoutes.admin,
      getPages: AppPages.pages,
    );
  }
}