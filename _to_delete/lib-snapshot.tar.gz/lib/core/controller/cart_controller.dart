import 'package:get/get.dart';
import 'package:lacarta/core/models/cart/cart.dart';
import 'package:lacarta/core/models/order.dart';
import 'package:lacarta/core/services/order_service.dart';
import 'package:lacarta/main.dart';

class CartController extends GetxController {
  final OrderService _orderService = OrderService();

  RxBool isLoading = false.obs;
  var cartItems = <CartItem>[].obs; //pedido

  void addToCart(CartItem cartItem) {
    cartItems.add(cartItem);
  }

  void increaseQuantity(CartItem item) {
    item.quantity++;
    cartItems.refresh();
  }

  void decreaseQuantity(CartItem item) {
    if (item.quantity > 1) {
      item.quantity--;
    } else {
      cartItems.remove(item);
    }
    cartItems.refresh();
  }

  void clearCart() {
    cartItems.clear();
  }

  int get totalItems => cartItems.fold(0, (sum, item) => sum + item.quantity);

  double get totalCart => cartItems.fold(0, (sum, item) => sum + (item.total));

  /// NOTA: revisa si esto y OrderController.saveOrder() están duplicando
  /// responsabilidad. Si el flujo real de "confirmar pedido" pasa por
  /// OrderController (WhatsApp), probablemente este método debería
  /// llamarse desde ahí, no tener su propia lógica de guardado aparte.
  Future<void> createCartOrder(OrderCart order) async {
    isLoading.value = true;
    try {
      await _orderService.saveOrder(order, currentRestaurant['id'] as String);
      clearCart();
    } catch (e) {
      Get.snackbar('Error', 'No se pudo realizar el pedido');
    } finally {
      isLoading.value = false;
    }
  }
}