import 'dart:async';

import 'package:get/get.dart';
import 'package:lacarta/core/constant/order_status.dart';
import 'package:lacarta/core/controller/auth_controller.dart';
import 'package:lacarta/core/models/admin_order.dart';
import 'package:lacarta/core/services/admin_order_service.dart';
import 'package:lacarta/core/services/api_client.dart';

class AdminOrdersController extends GetxController {
  final AdminOrderService _service = AdminOrderService();

  /// Cada cuánto se buscan pedidos nuevos automáticamente
  static const refreshEvery = Duration(seconds: 20);

  final orders = <AdminOrder>[].obs;

  /// null = todos
  final filter = RxnString();
  final isLoading = false.obs;
  final total = 0.obs;
  final updatingId = RxnString();
  final lastUpdated = Rxn<DateTime>();

  Timer? _timer;
  final Set<String> _knownIds = {};
  bool _firstLoad = true;

  String? get _companyId => AuthController.to.activeCompanyId.value;

  @override
  void onInit() {
    super.onInit();
    load();
    _timer = Timer.periodic(refreshEvery, (_) => load(silent: true));
  }

  @override
  void onClose() {
    _timer?.cancel();
    super.onClose();
  }

  Future<void> load({bool silent = false}) async {
    final companyId = _companyId;
    if (companyId == null) return;
    if (!silent) isLoading.value = true;
    try {
      final res = await _service.list(companyId, status: filter.value, limit: 50);
      _notifyNewOrders(res.data);
      orders.assignAll(res.data);
      total.value = res.total;
      lastUpdated.value = DateTime.now();
    } on ApiException catch (e) {
      if (!silent) Get.snackbar('Error', e.message);
    } finally {
      isLoading.value = false;
    }
  }

  /// Avisa cuando llega un pedido nuevo entre una actualización y otra
  void _notifyNewOrders(List<AdminOrder> fresh) {
    final newOnes = fresh
        .where((o) =>
            !_knownIds.contains(o.id) && o.status == OrderStatus.pending)
        .toList();
    _knownIds.addAll(fresh.map((o) => o.id));
    if (_firstLoad) {
      _firstLoad = false;
      return;
    }
    if (newOnes.isNotEmpty) {
      Get.snackbar(
        newOnes.length == 1
            ? 'Nuevo pedido #${newOnes.first.orderNumber}'
            : '${newOnes.length} pedidos nuevos',
        newOnes.map((o) => o.customerName).join(', '),
        duration: const Duration(seconds: 5),
      );
    }
  }

  void setFilter(String? status) {
    if (filter.value == status) return;
    filter.value = status;
    load();
  }

  Future<void> changeStatus(AdminOrder order, String status) async {
    final companyId = _companyId;
    if (companyId == null || updatingId.value != null) return;
    updatingId.value = order.id;
    try {
      final updated = await _service.updateStatus(companyId, order.id, status);
      final i = orders.indexWhere((o) => o.id == order.id);
      if (i != -1) {
        // Si hay un filtro activo y el pedido ya no cumple, sale de la lista
        if (filter.value != null && updated.status != filter.value) {
          orders.removeAt(i);
          total.value = total.value - 1;
        } else {
          orders[i] = updated;
        }
      }
    } on ApiException catch (e) {
      Get.snackbar('No se pudo actualizar', e.message);
    } finally {
      updatingId.value = null;
    }
  }
}
