import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lacarta/core/constant/custom_colors.dart';
import 'package:lacarta/core/constant/order_status.dart';
import 'package:lacarta/core/models/admin_order.dart';
import 'package:lacarta/core/utils/format.dart';
import 'package:lacarta/core/widget/responsive.dart';
import 'package:lacarta/features/admin/orders/admin_orders_controller.dart';
import 'package:url_launcher/url_launcher.dart';

/// Pedidos del restaurante: filtros por estado, detalle y cambio de estado.
/// Se actualiza solo cada 20 s y avisa cuando entra un pedido nuevo.
class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(AdminOrdersController());

    return Scaffold(
      backgroundColor: CustomColorBasic.white3,
      appBar: AppBar(
        title: const Text('Pedidos'),
        actions: [
          Obx(() {
            final t = c.lastUpdated.value;
            return t == null
                ? const SizedBox.shrink()
                : Center(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 4),
                      child: Text(
                        'Act. ${Fmt.orderTime(t)}',
                        style: const TextStyle(
                            fontSize: 12, color: CustomColorBasic.grey1),
                      ),
                    ),
                  );
          }),
          IconButton(
            tooltip: 'Actualizar',
            icon: const Icon(Icons.refresh),
            onPressed: () => c.load(),
          ),
        ],
      ),
      body: ResponsiveCenter(
        maxWidth: 1200,
        child: Column(
          children: [
            _StatusFilter(controller: c),
            Expanded(
              child: Obx(() {
                if (c.isLoading.value && c.orders.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                return RefreshIndicator(
                  onRefresh: () => c.load(),
                  child: c.orders.isEmpty
                      ? ListView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          children: const [
                            SizedBox(height: 120),
                            Icon(Icons.receipt_long,
                                size: 56, color: Colors.grey),
                            SizedBox(height: 12),
                            Center(child: Text('No hay pedidos aquí')),
                          ],
                        )
                      : _OrdersGrid(controller: c),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusFilter extends StatelessWidget {
  final AdminOrdersController controller;
  const _StatusFilter({required this.controller});

  @override
  Widget build(BuildContext context) {
    final options = <String?>[null, ...OrderStatus.all];
    return SizedBox(
      height: 56,
      child: Obx(() {
        final selected = controller.filter.value;
        return ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          itemCount: options.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (context, i) {
            final status = options[i];
            return ChoiceChip(
              label: Text(status == null ? 'Todos' : OrderStatus.label(status)),
              selected: selected == status,
              onSelected: (_) => controller.setFilter(status),
            );
          },
        );
      }),
    );
  }
}

/// 1, 2 o 3 columnas según el ancho
class _OrdersGrid extends StatelessWidget {
  final AdminOrdersController controller;
  const _OrdersGrid({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Builder(builder: (context) {
      const spacing = 12.0;
      const padding = 12.0;
      // Ancho útil sin LayoutBuilder (las tarjetas tienen Obx adentro)
      final w = Responsive.contentWidth(context, 1200) - padding * 2;
      final cols = w >= 1000 ? 3 : (w >= 640 ? 2 : 1);
      final cardWidth = (w - spacing * (cols - 1)) / cols;

      return SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(padding),
        child: Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: controller.orders
              .map((o) => SizedBox(
                    width: cardWidth,
                    child: _OrderCard(order: o, controller: controller),
                  ))
              .toList(),
        ),
      );
    });
  }
}

class _OrderCard extends StatelessWidget {
  final AdminOrder order;
  final AdminOrdersController controller;
  const _OrderCard({required this.order, required this.controller});

  void _showProof() {
    final url = order.paymentProofUrl!;
    Get.dialog(
      Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600, maxHeight: 800),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Comprobante · Pedido #${order.orderNumber} · ${Fmt.money(order.total)}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Abrir en otra pestaña',
                      icon: const Icon(Icons.open_in_new),
                      onPressed: () => launchUrl(Uri.parse(url),
                          webOnlyWindowName: '_blank'),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Get.back(),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: InteractiveViewer(
                    child: Image.network(
                      url,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('No se pudo cargar la imagen'),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmCancel() async {
    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: Text('¿Cancelar el pedido #${order.orderNumber}?'),
        content: const Text('Esta acción no se puede deshacer.'),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('No'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Get.back(result: true),
            child: const Text('Sí, cancelar'),
          ),
        ],
      ),
    );
    if (ok == true) controller.changeStatus(order, OrderStatus.cancelled);
  }

  @override
  Widget build(BuildContext context) {
    final color = OrderStatus.color(order.status);
    final next = OrderStatus.next(order.status);

    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color.withValues(alpha: 0.5), width: 1.2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Encabezado: número, tipo, hora y estado
            Row(
              children: [
                Text(
                  '#${order.orderNumber}',
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 8),
                Icon(OrderType.icon(order.type),
                    size: 18, color: CustomColorBasic.grey1),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    OrderType.label(order.type),
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: CustomColorBasic.grey1),
                  ),
                ),
                const Spacer(),
                _StatusBadge(status: order.status),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${Fmt.orderTime(order.createdAt)} · ${Fmt.ago(order.createdAt)}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const Divider(height: 20),

            // Cliente
            _InfoRow(icon: Icons.person_outline, text: order.customerName),
            if (order.tableNumber != null)
              _InfoRow(
                  icon: Icons.table_restaurant_outlined,
                  text: 'Mesa ${order.tableNumber}'),
            if (order.address != null)
              _InfoRow(icon: Icons.place_outlined, text: order.address!),
            if (order.phone != null)
              _InfoRow(
                icon: Icons.phone_outlined,
                text: order.phone!,
                onTap: () =>
                    launchUrl(Uri(scheme: 'tel', path: order.phone!)),
              ),
            const SizedBox(height: 8),

            // Productos
            ...order.items.map((item) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${item.quantity} x ',
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                          Expanded(
                            child: Text(item.productName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600)),
                          ),
                          Text(Fmt.money(item.lineTotal)),
                        ],
                      ),
                      ...item.extras.map((e) => Padding(
                            padding: const EdgeInsets.only(left: 24),
                            child: Text(
                              '+ ${e.quantity > 1 ? '${e.quantity} x ' : ''}${e.optionName}',
                              style: const TextStyle(
                                  fontSize: 13, color: CustomColorBasic.grey1),
                            ),
                          )),
                      if (item.comment != null && item.comment!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(left: 24, top: 2),
                          child: Text(
                            '“${item.comment}”',
                            style: const TextStyle(
                                fontSize: 13,
                                fontStyle: FontStyle.italic,
                                color: Colors.deepOrange),
                          ),
                        ),
                    ],
                  ),
                )),

            if (order.notes != null && order.notes!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('Nota: ${order.notes}',
                    style: const TextStyle(fontSize: 13)),
              ),
            ],

            const Divider(height: 20),

            // Pago
            Row(
              children: [
                Icon(PaymentMethod.icon(order.paymentMethod),
                    size: 18, color: CustomColorBasic.grey1),
                const SizedBox(width: 6),
                Text(PaymentMethod.label(order.paymentMethod)),
                const Spacer(),
                if (order.isTransfer && order.hasProof)
                  TextButton.icon(
                    onPressed: _showProof,
                    icon: const Icon(Icons.receipt, size: 18),
                    label: const Text('Ver comprobante'),
                  ),
              ],
            ),
            if (order.isTransfer &&
                !order.hasProof &&
                order.status == OrderStatus.pending)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 4, bottom: 6),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Sin comprobante en la app: revisa si lo envió por WhatsApp',
                  style: TextStyle(fontSize: 13),
                ),
              ),

            Row(
              children: [
                const Text('Total', style: TextStyle(fontSize: 16)),
                const Spacer(),
                Text(
                  Fmt.money(order.total),
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),

            // Acciones
            if (next != null || OrderStatus.canCancel(order.status)) ...[
              const SizedBox(height: 12),
              Obx(() {
                final busy = controller.updatingId.value == order.id;
                return Row(
                  children: [
                    if (OrderStatus.canCancel(order.status))
                      TextButton(
                        style: TextButton.styleFrom(
                            foregroundColor: Colors.red),
                        onPressed: busy ? null : _confirmCancel,
                        child: const Text('Cancelar'),
                      ),
                    const Spacer(),
                    if (next != null)
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                            backgroundColor: OrderStatus.color(next)),
                        onPressed: busy
                            ? null
                            : () => controller.changeStatus(order, next),
                        icon: busy
                            ? const SizedBox(
                                height: 16,
                                width: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.arrow_forward, size: 18),
                        // En transferencias, confirmar = verificar el pago
                        label: Text(next == OrderStatus.confirmed &&
                                order.isTransfer
                            ? 'Confirmar pago'
                            : OrderStatus.actionLabel(next)),
                      ),
                  ],
                );
              }),
            ],
          ],
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    final color = OrderStatus.color(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        OrderStatus.label(status),
        style: TextStyle(
            color: color, fontWeight: FontWeight.w600, fontSize: 12),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;
  const _InfoRow({required this.icon, required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: CustomColorBasic.grey1),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                decoration: onTap != null ? TextDecoration.underline : null,
              ),
            ),
          ),
        ],
      ),
    );
    return onTap == null ? row : InkWell(onTap: onTap, child: row);
  }
}
