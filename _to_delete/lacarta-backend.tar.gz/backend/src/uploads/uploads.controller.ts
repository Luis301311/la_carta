import {
  BadRequestException,
  Controller,
  Param,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { randomUUID } from 'crypto';
import { mkdirSync } from 'fs';
import { diskStorage } from 'multer';
import { extname, join, resolve } from 'path';
import { CompanyAccessGuard } from '../auth/guards/company-access.guard';
import { UUID_REGEX } from '../common/uuid';

const ALLOWED = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const uploadRoot = () => resolve(process.env.UPLOAD_DIR ?? 'uploads');
const maxBytes = () => parseInt(process.env.MAX_UPLOAD_MB ?? '5', 10) * 1024 * 1024;

/**
 * Sube imágenes a disco en uploads/<companyId>/ y devuelve la URL pública.
 * (En producción puedes cambiar esto por S3, Cloudinary o Supabase Storage
 * sin tocar el resto de la API: solo cambia lo que devuelve `url`.)
 */
@ApiTags('uploads')
@ApiBearerAuth()
@UseGuards(CompanyAccessGuard)
@Controller('companies/:companyId/uploads')
export class UploadsController {
  constructor(private readonly config: ConfigService) {}

  @Post('image')
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } })
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: (req, _file, cb) => {
          const companyId = String(req.params.companyId);
          if (!UUID_REGEX.test(companyId)) return cb(new BadRequestException('companyId inválido'), '');
          const dir = join(uploadRoot(), companyId);
          mkdirSync(dir, { recursive: true });
          cb(null, dir);
        },
        filename: (_req, file, cb) => {
          const ext = extname(file.originalname).toLowerCase() || '.jpg';
          cb(null, `${randomUUID()}${ext}`);
        },
      }),
      limits: { fileSize: maxBytes() },
      fileFilter: (_req, file, cb) => {
        if (!ALLOWED.includes(file.mimetype)) {
          return cb(new BadRequestException('Solo se permiten imágenes JPG, PNG, WEBP o GIF'), false);
        }
        cb(null, true);
      },
    }),
  )
  upload(@Param('companyId') companyId: string, @UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('Envía la imagen en el campo "file"');
    const base = (this.config.get<string>('PUBLIC_URL') ?? 'http://localhost:3000').replace(/\/$/, '');
    return { url: `${base}/uploads/${companyId}/${file.filename}` };
  }
}
